// Sidebar Toggle
const sidebar = document.querySelector('.sidebar-container');
const sidebarOpenTrigger = document.querySelector('.sidebar-open-trigger');
const sidebarCloseBtn = document.querySelector('.sidebar-menuclosebtn');

sidebarOpenTrigger.addEventListener('click', () => {
  document.body.classList.add('sidebar-open');
});

sidebarCloseBtn.addEventListener('click', () => {
  document.body.classList.remove('sidebar-open');
});
