const form = document.getElementById("chat-form");
const input = document.getElementById("user-input");
const messages = document.getElementById("chat-messages");
const stopButton = document.getElementById("stop-button");
const toggleBtn = document.getElementById("theme-toggle");
const body = document.body;
const container = document.querySelector(".chat-container");
const inputContainer = document.querySelector(".chat-input-container");

let typingInterval;

// Show a greeting message when the page loads
displayMessage("Hello! How can I assist you today?", "bot");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = input.value.trim();
  if (!message) return;

  // Show user message
  displayMessage(message, "user");
  input.value = "";
  input.focus();

  // Show loading indicator
  showStatus("Thinking...", "loading");

  try {
    const response = await fetch("/chat_api/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCSRFToken(),
      },
      body: JSON.stringify({ message: message }),
    });

    const data = await response.json();

    removeStatus("loading");
    showStatus("Typing...", "typing");

    setTimeout(() => {
      removeStatus("typing");
      displayBotResponseWordByWord(data.reply || "No response.");
    }, 400);
  } catch (err) {
    removeStatus("loading");
    removeStatus("typing");
    displayBotResponseWordByWord("⚠️ Error connecting to Gemini.");
    console.error(err);
  }
});

function displayMessage(text, sender) {
  const div = document.createElement("div");
  div.className = `message ${sender}`;
  div.innerHTML =
    sender === "user"
      ? `<i class="fas fa-user"></i> ${text}`
      : `<i class="fas fa-robot"></i> <span class="bot-text">${text}</span>`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function displayBotResponseWordByWord(text) {
  const div = document.createElement("div");
  div.className = "message bot";
  div.innerHTML = `<i class="fas fa-robot"></i> <span id="typing-text"></span>`;
  messages.appendChild(div);
  const typingText = div.querySelector("#typing-text");

  let i = 0;
  typingInterval = setInterval(() => {
    if (i < text.length) {
      typingText.textContent += text.charAt(i);
      i++;
      messages.scrollTop = messages.scrollHeight;
    } else {
      clearInterval(typingInterval);
      // Hide stop button when typing is complete
      stopButton.classList.add("hidden");
    }
  }, 30);

  stopButton.classList.remove("hidden");
}

function showStatus(text, id) {
  removeStatus(id);
  const div = document.createElement("div");
  div.className = `message status`;
  div.id = `${id}-status`;
  div.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${text}`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function removeStatus(id) {
  const el = document.getElementById(`${id}-status`);
  if (el) el.remove();
}

function getCSRFToken() {
  const cookie = document.cookie
    .split("; ")
    .find((row) => row.startsWith("csrftoken="));
  return cookie ? decodeURIComponent(cookie.split("=")[1]) : "";
}

// Stop response
stopButton.addEventListener("click", () => {
  clearInterval(typingInterval);
  stopButton.classList.add("hidden");
});

function applyTheme(isLight) {
  const method = isLight ? "add" : "remove";
  body.classList[method]("light-mode");
  container.classList[method]("light-mode");
  inputContainer.classList[method]("light-mode");
  input.classList[method]("light-mode");

  toggleBtn.textContent = isLight ? "☀️" : "🌙";
  localStorage.setItem("theme", isLight ? "light" : "dark");
}

const savedTheme = localStorage.getItem("theme");
applyTheme(savedTheme === "light");

toggleBtn.addEventListener("click", () => {
  const isLight = !body.classList.contains("light-mode");
  applyTheme(isLight);
});
