from django.urls import path
from django.shortcuts import render
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('courses/', views.courses, name='courses'),
    path('dashboard/home/', views.dashboard_home, name='dashboard-home'),
    path('dashboard/profile/', views.profile, name='profile'),
    path('dashboard/courses-enrolled/', views.courses_enrolled, name='courses-enrolled'),
    path('dashboard/courses-uploaded/', views.courses_uploaded, name='courses-uploaded'),
    path('dashboard/upload/', views.upload, name='uploade'),
    path('dashboard/<slug:slug>/course-edit/', views.course_edit, name='course-edit'),
    path('dashboard/<slug:slug>/delete/', views.delete_course, name='delete-course'),
    path('<str:instructor>/course/<slug:slug>/', views.course_details, name='course_details'),
    path('courses/<str:category>/', views.category, name='category'),
    path('Risezen_AI/', views.gemini, name='Risezen_AI'),
    path('chat_api/', views.chat_api, name='chat_api'),
    path('class_9/', views.nine_class, name='class_9'),
    path('class_10/', views.ten_class, name='class_10'),
    path('class_11/', views.eleven_class, name='class_11'),
    path('class_12/', views.twelve_class, name='class_12'),
]
